
'use client';
import items from '../data/items.json';
import Link from 'next/link';

export default function Mock(){
  const sample = (items as any[]).slice(0, 10);
  return (
    <section>
      <h2>Mock Test (short)</h2>
      <ol>
        {sample.map(i=>(
          <li key={i.id} style={{margin:'8px 0'}}>
            <Link href={`/task/${i.id}`}>{i.module} · {i.taskType}</Link>
          </li>
        ))}
      </ol>
      <p style={{fontSize:12, opacity:.7}}>This short mock uses 10 items. You can expand via the Admin.</p>
    </section>
  );
}
