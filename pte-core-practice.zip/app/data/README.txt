Generated at build: see scripts/generateItems.mjs
