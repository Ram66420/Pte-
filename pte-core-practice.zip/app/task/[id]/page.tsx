
'use client';
import items from '../../data/items.json';
import { useParams, useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useAppStore } from '../../lib/store';

function Timer({sec,onDone}:{sec:number,onDone:()=>void}){
  const [t,setT]=useState(sec);
  useEffect(()=>{
    const id=setInterval(()=>setT(x=>{
      if(x<=1){ clearInterval(id); onDone(); return 0;}
      return x-1;
    }),1000);
    return ()=>clearInterval(id);
  },[sec]);
  return <div aria-live="polite">Time: {t}s</div>;
}

export default function TaskPage(){
  const { id } = useParams();
  const item = useMemo(()=> (items as any[]).find(i=> String(i.id)===String(id)), [id]);
  const router = useRouter();
  const addAttempt = useAppStore(s=>s.addAttempt);

  const [answer,setAnswer]=useState<any>('');
  const [recording,setRecording]=useState(false);
  const mediaStream = useRef<MediaStream|null>(null);
  const mediaRec = useRef<MediaRecorder|null>(null);
  const chunks = useRef<Blob[]>([]);
  const [transcript,setTranscript]=useState<string>('');
  const [recognizerSupported,setRecognizerSupported]=useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(()=>{
    if(!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)){
      setRecognizerSupported(false);
    } else {
      setRecognizerSupported(true);
    }
  },[]);

  const startSpeaking = async ()=>{
    const sr = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if(sr){
      const recog = new sr();
      recognitionRef.current = recog;
      recog.continuous = true;
      recog.interimResults = true;
      recog.onresult = (e: any)=>{
        let t = '';
        for(let i=e.resultIndex;i<e.results.length;i++){
          t += e.results[i][0].transcript + ' ';
        }
        setTranscript(t.trim());
      };
      recog.start();
    }
    mediaStream.current = await navigator.mediaDevices.getUserMedia({audio:true});
    mediaRec.current = new MediaRecorder(mediaStream.current);
    chunks.current = [];
    mediaRec.current.ondataavailable = (e)=> chunks.current.push(e.data);
    mediaRec.current.start();
    setRecording(true);
  };
  const stopSpeaking = ()=>{
    mediaRec.current?.stop();
    mediaStream.current?.getTracks().forEach(t=>t.stop());
    if(recognitionRef.current){ recognitionRef.current.stop(); }
    setRecording(false);
  };

  const onFinish = async ()=>{
    if(recording) stopSpeaking();
    const audioBlob = chunks.current.length ? new Blob(chunks.current, {type:'audio/webm'}) : null;
    const form = new FormData();
    form.append('item', JSON.stringify(item));
    form.append('answer', typeof answer==='string'?answer:JSON.stringify(answer));
    form.append('transcript', transcript);
    if(audioBlob) form.append('audio', audioBlob, 'attempt.webm');
    const res = await fetch('/api/score', {method:'POST', body: form});
    const data = await res.json();
    addAttempt(data);
    router.push('/results');
  };

  if(!item){ return <div>Item not found.</div>; }

  return (
    <section>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h3>{item.module.toUpperCase()} · {item.taskType}</h3>
        <Timer sec={item.module==='speaking'?40:item.module==='writing'?600:120} onDone={onFinish}/>
      </div>

      {item.prompt && <p><b>Prompt:</b> {item.prompt}</p>}
      {item.question && <p><b>Question:</b> {item.question}</p>}
      {item.passage && <details open><summary>Reading Passage</summary><p>{item.passage}</p></details>}
      {item.text && <p>{item.text.replace(/___/g, '_____')}</p>}
      {item.imageCaption && <p><i>Image (described): {item.imageCaption}</i></p>}
      {item.audioText && <details><summary>Play Audio (text-to-speech)</summary><p>{item.audioText}</p></details>}
      {item.options && (
        <div>
          {item.options.map((o:string, idx:number)=>(
            <label key={idx} style={{display:'block', margin:'6px 0'}}>
              <input
                type={item.taskType==='mcq_multiple' || item.taskType==='highlight_correct_summary' ? 'checkbox' : 'radio'}
                name="opt"
                value={idx}
                onChange={(e)=>{
                  if(e.target.type==='checkbox'){
                    setAnswer((prev:number[]|string)=>{
                      const arr = Array.isArray(prev)? prev.slice(): [];
                      const v = Number(e.target.value);
                      const i = arr.indexOf(v);
                      if(e.target.checked && i<0) arr.push(v);
                      if(!e.target.checked && i>=0) arr.splice(i,1);
                      return arr;
                    });
                  } else {
                    setAnswer(Number(e.target.value));
                  }
                }}
              /> {o}
            </label>
          ))}
        </div>
      )}

      {(item.taskType==='fill_blanks_reading' || item.taskType==='fill_blanks_rw') && (
        <div style={{margin:'12px 0'}}>
          {item.blanks.map((_:string, idx:number)=>(
            <input key={idx} placeholder={`Blank ${idx+1}`} onChange={(e)=>{
              setAnswer((prev:any)=>{
                const arr = Array.isArray(prev)? prev.slice(): [];
                arr[idx] = e.target.value;
                return arr;
              });
            }} style={{marginRight:8}}/>
          ))}
        </div>
      )}

      {(item.module==='writing' || item.taskType==='summarize_spoken_text') && (
        <div style={{margin:'12px 0'}}>
          <textarea placeholder="Type your response..." rows={10} style={{width:'100%'}} onChange={e=>setAnswer(e.target.value)} />
          <div style={{fontSize:12, opacity:.7}}>Word count: {(answer||'').split(/\s+/).filter(Boolean).length}</div>
        </div>
      )}

      {item.module==='speaking' && (
        <div style={{margin:'12px 0'}}>
          <div>Speech recognition: {recognizerSupported ? 'available' : 'unavailable'}; Transcript: {transcript||'(none yet)'} </div>
          {!recording ? <button onClick={startSpeaking}>Start Recording</button> : <button onClick={stopSpeaking}>Stop</button>}
        </div>
      )}

      <div style={{marginTop:16, display:'flex', gap:8}}>
        <button onClick={onFinish}>Submit</button>
      </div>
    </section>
  );
}
