
'use client';
import items from '../data/items.json';
import { useState } from 'react';

export default function Admin(){
  const [data, setData] = useState<any[]>(items as any[]);
  const exportJson = ()=>{
    const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'items-export.json'; a.click();
    URL.revokeObjectURL(url);
  };
  const importJson = (file: File)=>{
    const reader = new FileReader();
    reader.onload = ()=>{
      try{ setData(JSON.parse(String(reader.result))); alert('Imported!'); }
      catch(e){ alert('Invalid JSON'); }
    };
    reader.readAsText(file);
  };
  return (
    <section>
      <h2>Admin (local)</h2>
      <p>Export/import items JSON. (For full CRUD connect a DB.)</p>
      <div style={{display:'flex', gap:8}}>
        <button onClick={exportJson}>Export Items</button>
        <label><input type="file" accept="application/json" onChange={(e)=>{
          const f = e.target.files?.[0]; if(f) importJson(f);
        }}/></label>
      </div>
      <p>Total items loaded: {data.length}</p>
    </section>
  );
}
