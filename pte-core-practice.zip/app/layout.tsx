
import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'PTE Core Practice (Unofficial)',
  description: 'Practice PTE Core with AI-style scoring and instant feedback.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header style={{padding:'12px', borderBottom:'1px solid #eee', display:'flex', gap:16}}>
          <b>PTE Core Practice (Unofficial)</b>
          <nav style={{display:'flex', gap:12}}>
            <Link href="/">Home</Link>
            <Link href="/practice">Practice</Link>
            <Link href="/mock">Mock Test</Link>
            <Link href="/results">Results</Link>
            <Link href="/admin">Admin</Link>
          </nav>
        </header>
        <main style={{padding:'16px'}}>{children}</main>
      </body>
    </html>
  );
}
