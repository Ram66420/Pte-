
export default function About(){
  return (
    <article>
      <h2>About</h2>
      <p>This is an unofficial PTE Core practice site. All items are original and generated locally.</p>
      <p>Speaking uses the browser Web Speech API when available; otherwise, fluency is estimated from audio.</p>
    </article>
  );
}
