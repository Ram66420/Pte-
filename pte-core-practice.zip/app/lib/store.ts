
'use client';
import { create } from 'zustand';

type Attempt = any;

interface State {
  attempts: Attempt[];
  addAttempt: (a: Attempt)=>void;
  clear: ()=>void;
}

export const useAppStore = create<State>((set,get)=>({
  attempts: [],
  addAttempt: (a)=> set({ attempts: [...get().attempts, a] }),
  clear: ()=> set({ attempts: [] })
}));
