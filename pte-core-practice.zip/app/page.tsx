
import Link from 'next/link';

export default function Home() {
  return (
    <section>
      <h1>PTE Core Practice (Unofficial)</h1>
      <p>Practice Speaking, Writing, Reading, and Listening with timers, realistic flows, and AI-style scoring.</p>
      <ul>
        <li><Link href="/practice">Targeted Practice</Link></li>
        <li><Link href="/mock">Full Mock Test</Link></li>
        <li><Link href="/results">Your Results</Link></li>
        <li><Link href="/about">About</Link></li>
      </ul>
      <p style={{fontSize:12, opacity:.8}}>This site is unofficial and for practice only.</p>
    </section>
  );
}
