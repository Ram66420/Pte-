
'use client';
import items from '../data/items.json';
import { useState, useMemo } from 'react';
import Link from 'next/link';

const groups = ['speaking','writing','reading','listening'] as const;

export default function Practice(){
  const [filter, setFilter] = useState<typeof groups[number]>('speaking');
  const list = useMemo(()=> (items as any[]).filter(i=>i.module===filter).slice(0,25), [filter]);
  return (
    <section>
      <h2>Targeted Practice</h2>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        {groups.map(g=>(
          <button key={g} onClick={()=>setFilter(g)} aria-pressed={filter===g}>{g}</button>
        ))}
      </div>
      <ul style={{display:'grid', gap:8, padding:0, listStyle:'none'}}>
        {list.map((i:any)=>(
          <li key={i.id} style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
            <div style={{display:'flex', justifyContent:'space-between'}}>
              <b>{i.taskType}</b>
              <Link href={`/task/${i.id}`}>Start</Link>
            </div>
            <div style={{fontSize:12, opacity:.8}}>#{i.id}</div>
          </li>
        ))}
      </ul>
    </section>
  );
}
