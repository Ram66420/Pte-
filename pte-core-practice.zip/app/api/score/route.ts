
import { NextRequest, NextResponse } from 'next/server';

function clamp(n:number,min=0,max=90){ return Math.max(min, Math.min(max, Math.round(n))); }
function wc(s:string){ return (s||'').trim().split(/\s+/).filter(Boolean).length; }
function similarity(a:string,b:string){
  a=(a||'').toLowerCase(); b=(b||'').toLowerCase();
  const aset=new Set(a.split(/[^a-z]+/)), bset=new Set(b.split(/[^a-z]+/));
  const inter=[...aset].filter(x=>bset.has(x)).length;
  const denom=Math.max(1, Math.max(aset.size, bset.size));
  return inter/denom;
}

export async function POST(req: NextRequest){
  const form = await req.formData();
  const item = JSON.parse(String(form.get('item')));
  const answerRaw = String(form.get('answer')||'');
  const transcript = String(form.get('transcript')||'');
  const audio = form.get('audio') as File | null;

  const attemptId = crypto.randomUUID();
  const moduleName = item.module;
  const taskType = item.taskType;

  let content=0, pronunciation=0, fluency=0, coherence=0, grammar=0, spelling=0, vocabulary=0, task_response=0;
  let overall=0;
  let rationale = '';
  let tips: string[] = [];
  let objectiveScore=0, maxObjective=0;
  let wpm=0, avgPauseMs=0, pauseCount=0, filledPauses=0, phonemeAccuracy=0;

  // rudimentary writing scoring
  if(moduleName==='writing' || taskType==='summarize_spoken_text'){
    const ans = answerRaw;
    const words = wc(ans);
    const hasParagraphs = ans.split(/\n{2,}/).length>1;
    content = clamp(words>15? 50 + Math.min(40, words/3) : words*2);
    coherence = clamp((hasParagraphs?65:50) + Math.min(20, Math.floor(words/20)));
    // naive grammar: fewer symbols and repeated spaces -> better
    const errors = (ans.match(/\s{2,}|,{2,}|\.{3,}/g)||[]).length;
    grammar = clamp(80 - errors*5);
    spelling = clamp(75 - (ans.match(/ teh | recieve | definately /gi)||[]).length*10);
    vocabulary = clamp(60 + Math.min(30, Math.floor(new Set(ans.toLowerCase().split(/[^a-z]+/).filter(Boolean)).size/20*30)));
    task_response = clamp(words>100?80:50 + Math.min(30, Math.floor(words/10)));
    overall = clamp((content+coherence+grammar+spelling+vocabulary+task_response)/6);
    rationale = 'Scored by length, structure, error density, and lexical variety.';
    tips = ['Organize into clear paragraphs.','Reduce filler and repeated words.'];
  }

  // speaking scoring
  if(moduleName==='speaking'){
    const ref = item.referenceText || item.audioText || '';
    const sim = similarity(transcript, ref);
    content = clamp(sim*90);
    pronunciation = clamp(60 + sim*30); // proxy via transcript similarity
    fluency = clamp(50 + Math.min(40, (transcript.split(' ').length)));
    task_response = clamp(sim*90);
    overall = clamp((content + pronunciation + fluency + task_response)/4);
    rationale = 'Speaking scored via transcript similarity and length; fluency approximated from words recognized.';
    tips = ['Aim for steady pace and minimal long pauses.','Match key words from the prompt.'];
  }

  // objective reading/listening
  if(moduleName==='reading' || moduleName==='listening'){
    if(Array.isArray(item.correct)){
      maxObjective = item.correct.length;
      const ans = answerRaw ? JSON.parse(answerRaw) : (Array.isArray(item.correct)?[]:null);
      const a = Array.isArray(ans)? ans: [Number(ans)];
      const correct = new Set(item.correct);
      objectiveScore = a.filter((v:number)=> correct.has(v)).length;
      content = clamp(objectiveScore/maxObjective*90);
      task_response = content;
      overall = content;
      rationale = 'Objective scoring with partial credit.';
      tips = ['Eliminate distractors strategically.','Scan for meaning and keywords.'];
    } else if(item.blanks){
      maxObjective = item.blanks.length;
      const ans = answerRaw ? JSON.parse(answerRaw) : [];
      objectiveScore = item.blanks.filter((w:string, i:number)=> (ans[i]||'').toLowerCase()===w.toLowerCase()).length;
      content = clamp(objectiveScore/maxObjective*90);
      task_response = content;
      overall = content;
      rationale = 'Exact-match scoring for blanks.';
      tips = ['Use context clues for grammar and collocations.','Check spelling carefully.'];
    } else if(taskType==='highlight_incorrect_words'){
      // simple: award full if the provided incorrect word is spotted in shownText
      const incorrect = new Set(item.incorrect||[]);
      maxObjective = incorrect.size;
      const ansArr = (answerRaw||'').split(/\s+/).filter(Boolean);
      objectiveScore = ansArr.filter(w=> incorrect.has(w)).length;
      overall = clamp(objectiveScore/maxObjective*90);
      content = overall; task_response = overall;
      rationale = 'Counts correctly identified incorrect words.';
      tips = ['Track the audio while reading carefully.','Focus on mismatched words.'];
    } else if(taskType==='write_from_dictation'){
      const sim = similarity(answerRaw, item.audioText||'');
      overall = clamp(sim*90); content = overall; task_response = overall;
      rationale = 'Similarity to reference sentence.';
      tips = ['Capitalize properly and watch spelling.','Replay mentally before typing.'];
    }
  }

  const payload = {
    attemptId,
    module: moduleName,
    taskType,
    scores: {
      overall,
      dimensions: { content, pronunciation, fluency, coherence, grammar, spelling, vocabulary, task_response }
    },
    rationale,
    tips,
    wordCount: wc(answerRaw),
    speechMetrics: { wpm, avgPauseMs, pauseCount, filledPauses, phonemeAccuracy },
    answerKeyCheck: { objectiveScore, maxObjective, details: [] },
    timing: { allocatedSec: 0, usedSec: 0 },
    metadata: { modelVersion: 'local-heuristic-v1', strictMode: false }
  };

  return NextResponse.json(payload);
}
