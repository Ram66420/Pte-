
'use client';
import { useAppStore } from '../lib/store';

export default function Results(){
  const attempts = useAppStore(s=>s.attempts);
  return (
    <section>
      <h2>Results</h2>
      {!attempts.length && <p>No attempts yet.</p>}
      <ul style={{listStyle:'none', padding:0, display:'grid', gap:12}}>
        {attempts.map((a:any)=>(
          <li key={a.attemptId} style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
            <div><b>{a.module}</b> · {a.taskType} · Score: <b>{a.scores?.overall}</b></div>
            <pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(a, null, 2)}</pre>
          </li>
        ))}
      </ul>
    </section>
  );
}
