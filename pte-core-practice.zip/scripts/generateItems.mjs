
import fs from 'fs';
import path from 'path';

const outDir = path.join(process.cwd(), 'app', 'data');
fs.mkdirSync(outDir, { recursive: true });

const modules = {
  speaking: ['read_aloud','repeat_sentence','describe_image','retell_lecture','short_question'],
  writing: ['summarize_written_text','write_essay'],
  reading: ['mcq_single','mcq_multiple','reorder_paragraphs','fill_blanks_reading','fill_blanks_rw'],
  listening: ['summarize_spoken_text','fill_blanks_listening','highlight_correct_summary','select_missing_word','highlight_incorrect_words','write_from_dictation']
};

function rand(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function shuffle(a){ for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; }
function words(n){ const base = "urban river climate device curious lantern orbit velvet meadow brisk canyon subtle willow vibrant humble radiant shimmer vivid mosaic amber cobalt lilac cedar ivory quartz saffron jasper linen granite maple citrus coral azure".split(" "); return shuffle([...base]).slice(0,n).join(" "); }

const items = [];
let id = 1;

function makeSpeaking(){
  const type = rand(modules.speaking);
  if(type==='read_aloud'){
    const text = `Read the passage aloud: "${words(30)}."`;
    return { id:id++, module:'speaking', taskType:type, prompt:text, referenceText:text };
  }
  if(type==='repeat_sentence'){
    const ref = `The ${words(6)} project begins next Monday.`;
    return { id:id++, module:'speaking', taskType:type, prompt:"Listen and repeat the sentence.", audioText: ref, referenceText: ref };
  }
  if(type==='describe_image'){
    const caption = `A chart shows ${words(10)} over four years.`;
    return { id:id++, module:'speaking', taskType:type, prompt:"Describe the image in detail.", imageCaption: caption, referencePoints: ["mention trend","compare categories","conclude briefly"] };
  }
  if(type==='retell_lecture'){
    const key = ["topic","two key points","brief conclusion"];
    return { id:id++, module:'speaking', taskType:type, prompt:"Listen to a short talk and retell it.", referencePoints:key, audioText:`Lecture about ${words(10)}.` };
  }
  // short_question
  return { id:id++, module:'speaking', taskType:'short_question', prompt:"What device do you use to measure temperature?", answerKey:"thermometer" };
}

function makeWriting(){
  const type = rand(modules.writing);
  if(type==='summarize_written_text'){
    const passage = `In many cities, ${words(25)}. Policies encourage public transport, yet adoption varies by neighborhood.`;
    const model = "Cities benefit from public transport, but uptake differs across neighborhoods due to local factors.";
    return { id:id++, module:'writing', taskType:type, passage, modelAnswer:model };
  }
  // write_essay
  const prompt = "Do the advantages of working remotely outweigh the disadvantages? Provide reasons and examples.";
  const hints = ["state a clear thesis","use cohesive paragraphs","provide examples","finish with a recommendation"];
  return { id:id++, module:'writing', taskType:'write_essay', prompt, hints };
}

function makeReading(){
  const type = rand(modules.reading);
  if(type==='mcq_single'){
    const q = "Which factor most improves energy efficiency in homes?";
    const opts = ["Thicker insulation","Open windows in winter","Leaving lights on","Running hot water continuously"];
    return { id:id++, module:'reading', taskType:type, question:q, options:opts, correct:[0] };
  }
  if(type==='mcq_multiple'){
    const q = "Select two benefits of urban trees.";
    const opts = ["Reduce heat","Increase noise","Improve air quality","Block all sunlight"];
    return { id:id++, module:'reading', taskType:type, question:q, options:opts, correct:[0,2] };
  }
  if(type==='reorder_paragraphs'){
    const paras = ["First, scientists gathered baseline data.","Next, they implemented the new process.","Then, they compared outcomes over time.","Finally, they published recommendations."];
    return { id:id++, module:'reading', taskType:type, paragraphs:shuffle([...paras]), correctOrder:[0,1,2,3] };
  }
  if(type==='fill_blanks_reading'){
    const text = "Efficient buildings ___ energy by improving insulation and using smart controls.";
    return { id:id++, module:'reading', taskType:type, text, blanks:["save"] };
  }
  // fill_blanks_rw
  const text = "Cities often ___ new bike lanes to encourage safer travel.";
  return { id:id++, module:'reading', taskType:'fill_blanks_rw', text, blanks:["build"] };
}

function makeListening(){
  const type = rand(modules.listening);
  if(type==='summarize_spoken_text'){
    const audioText = `Speech about ${words(20)}.`;
    const model = "The talk outlines a topic, two supporting points, and a short conclusion.";
    return { id:id++, module:'listening', taskType:type, audioText, modelAnswer:model };
  }
  if(type==='fill_blanks_listening'){
    const audioText = "Public transit can lower congestion and pollution.";
    const blanks = ["congestion","pollution"];
    return { id:id++, module:'listening', taskType:type, audioText, blanks };
  }
  if(type==='highlight_correct_summary'){
    const audioText = `Brief on ${words(15)}.`;
    const options = [
      "Captures the main idea and two details.",
      "Focuses on unrelated topics.",
      "Lists numbers without context.",
      "Describes a different field entirely."
    ];
    return { id:id++, module:'listening', taskType:type, audioText, options, correct:[0] };
  }
  if(type==='select_missing_word'){
    const audioText = "With better planning, the project finished ahead of ____.";
    return { id:id++, module:'listening', taskType:type, audioText, options:["schedule","budget","weather","meetings"], correct:[0] };
  }
  if(type==='highlight_incorrect_words'){
    const audioText = "The city expanded rail service during the summer months.";
    const shown = "The city expanded rail service during the winter months.";
    const incorrect = ["winter"];
    return { id:id++, module:'listening', taskType:type, audioText, shownText:shown, incorrect };
  }
  // write_from_dictation
  const audioText = "Energy demand usually peaks in late afternoon.";
  return { id:id++, module:'listening', taskType:'write_from_dictation', audioText };
}

const target = 130;
while(items.length < target){
  const bucket = Math.floor(Math.random()*4);
  if(bucket===0) items.push(makeSpeaking());
  else if(bucket===1) items.push(makeWriting());
  else if(bucket===2) items.push(makeReading());
  else items.push(makeListening());
}

fs.writeFileSync(path.join(outDir, 'items.json'), JSON.stringify(items, null, 2), 'utf-8');
console.log(`Generated ${items.length} items to app/data/items.json`);
